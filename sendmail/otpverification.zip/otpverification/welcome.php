<html>
    <head>
        <style>
            body{background:green;}
            </style>
</head>
    <body>
        <h1>welcome to user</h1>

</body>
</html>